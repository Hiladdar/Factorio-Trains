data:extend({


  {
    type = "fluid-wagon",
    name = "hsmd-fluid-wagon-mk3",
    icon = "__Hiladdar_Trains__/graphics/icons/hsmd-fluid-wagon-mk3.png",
    icon_size = 32,
    flags = {"placeable-neutral", "player-creation", "placeable-off-grid"},
    minable = {mining_time = 1, result = "hsmd-fluid-wagon-mk3"},
    mined_sound = {filename = "__core__/sound/deconstruct-medium.ogg"},
    max_health = 400,
    capacity = 75000,
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    collision_box = {{-0.6, -2.4}, {0.6, 2.4}},
    selection_box = {{-1, -2.703125}, {1, 3.296875}},
    vertical_selection_shift = -0.796875,
    weight = 1600,
    max_speed = 1000,
    braking_force = 3,
    friction_force = 0.50,
    air_resistance = 0.03,
    connection_distance = 3,
    joint_distance = 4,
    energy_per_hit_point = 6,
    resistances =
    {
      {
        type = "fire",
        decrease = 15,
        percent = 50
      },
      {
        type = "physical",
        decrease = 15,
        percent = 30
      },
      {
        type = "impact",
        decrease = 50,
        percent = 60
      },
      {
        type = "explosion",
        decrease = 15,
        percent = 30
      },
      {
        type = "acid",
        decrease = 10,
        percent = 20
      }
    },
    back_light = rolling_stock_back_light(),
    stand_by_light = rolling_stock_stand_by_light(),
    color = {r = 0.718, g = 0.176, b = 0.173, a = 0.5},
    pictures =
    {
      layers =
      {
        {
          priority = "very-low",
          slice = 4,
          width = 208,
          height = 210,
          back_equals_front = true,
          direction_count = 128,
          allow_low_quality_rotation = true,
          filenames =
          {
            "__Hiladdar_Trains__/graphics/entity/fluid-wagon/hsmd-fluid-wagon-mk3-1.png",
            "__Hiladdar_Trains__/graphics/entity/fluid-wagon/hsmd-fluid-wagon-mk3-2.png",
            "__Hiladdar_Trains__/graphics/entity/fluid-wagon/hsmd-fluid-wagon-mk3-3.png",
            "__Hiladdar_Trains__/graphics/entity/fluid-wagon/hsmd-fluid-wagon-mk3-4.png"
          },
          line_length = 4,
          lines_per_file = 8,
          shift = {0 + 0.013, -1 + 0.077},
          hr_version =
          {
            priority = "very-low",
            slice = 4,
            width = 416,
            height = 419,
            back_equals_front = true,
            direction_count = 128,
            allow_low_quality_rotation = true,
            filenames =
            {
              "__Hiladdar_Trains__/graphics/entity/fluid-wagon/hsmd-hr-fluid-wagon-mk3-1.png",
              "__Hiladdar_Trains__/graphics/entity/fluid-wagon/hsmd-hr-fluid-wagon-mk3-2.png",
              "__Hiladdar_Trains__/graphics/entity/fluid-wagon/hsmd-hr-fluid-wagon-mk3-3.png",
              "__Hiladdar_Trains__/graphics/entity/fluid-wagon/hsmd-hr-fluid-wagon-mk3-4.png",
              "__Hiladdar_Trains__/graphics/entity/fluid-wagon/hsmd-hr-fluid-wagon-mk3-5.png",
              "__Hiladdar_Trains__/graphics/entity/fluid-wagon/hsmd-hr-fluid-wagon-mk3-6.png",
              "__Hiladdar_Trains__/graphics/entity/fluid-wagon/hsmd-hr-fluid-wagon-mk3-7.png",
              "__Hiladdar_Trains__/graphics/entity/fluid-wagon/hsmd-hr-fluid-wagon-mk3-8.png"
            },
            line_length = 4,
            lines_per_file = 4,
            shift = {0 + 0.013, -1 + 0.077},
            scale = 0.5
          }
        },
        {
          flags = { "shadow" },
          priority = "very-low",
          slice = 4,
          width = 251,
          height = 188,
          back_equals_front = true,
          draw_as_shadow = true,
          direction_count = 128,
          allow_low_quality_rotation = true,
          filenames =
          {
            "__base__/graphics/entity/fluid-wagon/fluid-wagon-shadow-1.png",
            "__base__/graphics/entity/fluid-wagon/fluid-wagon-shadow-2.png",
            "__base__/graphics/entity/fluid-wagon/fluid-wagon-shadow-3.png",
            "__base__/graphics/entity/fluid-wagon/fluid-wagon-shadow-4.png"
          },
          line_length = 4,
          lines_per_file = 8,
          shift = {0.875 + 0.013, 0.3125 + 0.077},
          hr_version =
          {
            flags = { "shadow" },
            priority = "very-low",
            slice = 4,
            width = 501,
            height = 375,
            back_equals_front = true,
            draw_as_shadow = true,
            direction_count = 128,
            allow_low_quality_rotation = true,
            filenames =
            {
              "__base__/graphics/entity/fluid-wagon/hr-fluid-wagon-shadow-1.png",
              "__base__/graphics/entity/fluid-wagon/hr-fluid-wagon-shadow-2.png",
              "__base__/graphics/entity/fluid-wagon/hr-fluid-wagon-shadow-3.png",
              "__base__/graphics/entity/fluid-wagon/hr-fluid-wagon-shadow-4.png",
              "__base__/graphics/entity/fluid-wagon/hr-fluid-wagon-shadow-5.png",
              "__base__/graphics/entity/fluid-wagon/hr-fluid-wagon-shadow-6.png",
              "__base__/graphics/entity/fluid-wagon/hr-fluid-wagon-shadow-7.png"
            },
            line_length = 4,
            lines_per_file = 5,
            shift = {0.875 + 0.013, 0.3125 + 0.077},
            scale = 0.5
          }
        }
      }
    },
    wheels = standard_train_wheels,
    rail_category = "regular",
    drive_over_tie_trigger = drive_over_tie(),
    tie_distance = 50,
    working_sound =
    {
      sound =
      {
        filename = "__base__/sound/train-wheels.ogg",
        volume = 0.6
      },
      match_volume_to_activity = true
    },
    crash_trigger = crash_trigger(),
    sound_minimum_speed = 0.5;
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 }
  }


})
data:extend(
{
  {
      type = "technology",
      name = "hsmd-cargo-wagon-mk4",
      icon = "__Hiladdar_Trains__/graphics/technology/hsmd-cargo-wagon-mk4.png",
	  icon_size = 128,
      effects =
      {
        {
            type = "unlock-recipe",
            recipe = "hsmd-cargo-wagon-mk4"
        },
        {
            type = "unlock-recipe",
            recipe = "hsmd-fluid-wagon-mk4"
        }
      },
	  prerequisites = {"hsmd-cargo-wagon-mk3"},
      unit =
      {
        count = 400,
        ingredients =
        {
			{"science-pack-1", 1},
			{"science-pack-2", 1},
			{"science-pack-3", 1},
			{"production-science-pack", 1},
			{"high-tech-science-pack", 1}
        },
        time = 60
      }
  }
}
)
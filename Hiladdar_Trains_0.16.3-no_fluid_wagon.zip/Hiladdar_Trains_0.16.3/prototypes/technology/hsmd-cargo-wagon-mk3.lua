data:extend(
{
  {
      type = "technology",
      name = "hsmd-cargo-wagon-mk3",
      icon = "__Hiladdar_Trains__/graphics/technology/hsmd-cargo-wagon-mk3.png",
	  icon_size = 128,
      effects =
      {
        {
            type = "unlock-recipe",
            recipe = "hsmd-cargo-wagon-mk3"
        },
        {
            type = "unlock-recipe",
            recipe = "hsmd-fluid-wagon-mk3"
        }
      },
	  prerequisites = {"hsmd-cargo-wagon-mk2"},
      unit =
      {
        count = 300,
        ingredients =
        {
			{"science-pack-1", 1},
			{"science-pack-2", 1},
			{"science-pack-3", 1},
			{"production-science-pack", 1}
        },
        time = 45
      }
  }
}
)
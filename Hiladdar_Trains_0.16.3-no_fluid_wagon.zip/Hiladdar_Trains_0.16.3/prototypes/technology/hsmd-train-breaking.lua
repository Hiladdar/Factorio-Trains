data:extend({

   {
    type = "technology",
    name = "braking-force-8",
    icon_size = 128,
    icon = "__base__/graphics/technology/braking-force.png",
    effects =
    {
      {
        type = "train-braking-force-bonus",
        modifier = 0.25
      }
    },
    prerequisites = {"braking-force-7"},
    -- prerequisites = {"braking-force-7","hsmd-self-enriching-fuel"},
    unit =
    {
      count_formula = "2000*(L-7)-1000",
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1},
        {"science-pack-3", 1},
        {"production-science-pack", 1},
        {"high-tech-science-pack", 1},
        {"space-science-pack", 1}
      },
      time = 60
    },
    upgrade = true,
    max_level = "infinite",
    order = "b-f-h"
  }


})
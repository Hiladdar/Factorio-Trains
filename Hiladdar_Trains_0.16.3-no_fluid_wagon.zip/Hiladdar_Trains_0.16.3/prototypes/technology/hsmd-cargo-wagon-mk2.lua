data:extend(
{
  {
      type = "technology",
      name = "hsmd-cargo-wagon-mk2",
      icon = "__Hiladdar_Trains__/graphics/technology/hsmd-cargo-wagon-mk2.png",
	  icon_size = 128,
      effects =
      {
        {
            type = "unlock-recipe",
            recipe = "hsmd-cargo-wagon-mk2"
        },
        {
            type = "unlock-recipe",
            recipe = "hsmd-fluid-wagon-mk2"
        }

      },
	  prerequisites = {"railway", "fluid-wagon"},
      unit =
      {
        count = 200,
        ingredients =
        {
			{"science-pack-1", 1},
			{"science-pack-2", 1},
			{"science-pack-3", 1}
        },
        time = 45
      }
  }
}
)
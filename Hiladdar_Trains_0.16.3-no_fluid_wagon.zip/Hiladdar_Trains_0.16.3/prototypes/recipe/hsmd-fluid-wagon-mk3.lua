data:extend ({

  {
    type = "recipe",
    name = "hsmd-fluid-wagon-mk3",
    enabled = false,
    energy_required = 3,
    ingredients =
    {
      {"hsmd-fluid-wagon-mk2", 1},
      {"fluid-wagon", 1},
      {"steel-plate", 18},
      {"pump", 3}
    },
    result = "hsmd-fluid-wagon-mk3"
  }

})

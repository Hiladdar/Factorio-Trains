data:extend({
  {
    type = "recipe",
    name = "hsmd-cargo-wagon-mk3",
    energy_required = 3,
    enabled = "false",
    ingredients = 
    {
      {"hsmd-cargo-wagon-mk2",1},
      {"cargo-wagon",1},
      {"steel-plate",18},
      {"stack-inserter",6}

    },
    result = "hsmd-cargo-wagon-mk3"
  }
  }
  )
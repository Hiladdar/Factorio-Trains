data:extend({
  {
    type = "recipe",
    name = "hsmd-cargo-wagon-mk2",
    energy_required = 2,
    enabled = "false",
    ingredients = 
    {
      {"cargo-wagon",2},
      {"steel-plate",18},
      {"stack-inserter",6}
    },
    result = "hsmd-cargo-wagon-mk2"
  }
  }
  )
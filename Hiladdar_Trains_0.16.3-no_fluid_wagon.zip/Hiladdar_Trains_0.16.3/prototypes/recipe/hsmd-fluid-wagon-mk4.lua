data:extend ({

  {
    type = "recipe",
    name = "hsmd-fluid-wagon-mk4",
    enabled = false,
    energy_required = 4,
    ingredients =
    {
      {"hsmd-fluid-wagon-mk3", 1},
      {"fluid-wagon", 1},
      {"steel-plate", 18},
      {"pump", 3}
    },
    result = "hsmd-fluid-wagon-mk4"
  }

})

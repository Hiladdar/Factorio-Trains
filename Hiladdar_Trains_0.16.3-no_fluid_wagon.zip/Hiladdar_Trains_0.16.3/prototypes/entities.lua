require("entity.hsmd-cargo-wagon-mk2")
require("entity.hsmd-cargo-wagon-mk3")
require("entity.hsmd-cargo-wagon-mk4")

require("entity.hsmd-fluid-wagon-mk2")
require("entity.hsmd-fluid-wagon-mk3")
require("entity.hsmd-fluid-wagon-mk4")
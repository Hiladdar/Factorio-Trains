require("recipe.hsmd-cargo-wagon-mk2")
require("recipe.hsmd-cargo-wagon-mk3")
require("recipe.hsmd-cargo-wagon-mk4")

require("recipe.hsmd-fluid-wagon-mk2")
require("recipe.hsmd-fluid-wagon-mk3")
require("recipe.hsmd-fluid-wagon-mk4")
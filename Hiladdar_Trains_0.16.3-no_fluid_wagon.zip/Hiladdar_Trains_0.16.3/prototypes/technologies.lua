require("technology.hsmd-cargo-wagon-mk2")
require("technology.hsmd-cargo-wagon-mk3")
require("technology.hsmd-cargo-wagon-mk4")

require("technology.hsmd-train-breaking")
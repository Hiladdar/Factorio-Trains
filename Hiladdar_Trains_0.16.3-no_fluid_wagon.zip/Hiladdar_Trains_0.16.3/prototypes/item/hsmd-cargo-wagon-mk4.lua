data:extend(
{
  {
    type = "item-with-entity-data",
    name = "hsmd-cargo-wagon-mk4",
    icon = "__Hiladdar_Trains__/graphics/icons/hsmd-cargo-wagon-mk4.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "a[train-system]-h[cargo-wagon]-c",
    place_result = "hsmd-cargo-wagon-mk4",
    stack_size = 5
  }
  }
  )
data:extend ({

  {
    type = "item-with-entity-data",
    name = "hsmd-fluid-wagon-mk3",
    icon = "__Hiladdar_Trains__/graphics/icons/hsmd-fluid-wagon-mk3.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "a[train-system]-h[fluid-wagon]-b",
    place_result = "hsmd-fluid-wagon-mk3",
    stack_size = 5
  }

})
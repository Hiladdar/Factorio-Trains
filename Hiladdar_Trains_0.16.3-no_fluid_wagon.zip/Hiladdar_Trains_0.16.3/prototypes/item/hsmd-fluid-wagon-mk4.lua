data:extend ({

  {
    type = "item-with-entity-data",
    name = "hsmd-fluid-wagon-mk4",
    icon = "__Hiladdar_Trains__/graphics/icons/hsmd-fluid-wagon-mk4.png",
    icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "transport",
    order = "a[train-system]-h[fluid-wagon]-c",
    place_result = "hsmd-fluid-wagon-mk4",
    stack_size = 5
  }

})
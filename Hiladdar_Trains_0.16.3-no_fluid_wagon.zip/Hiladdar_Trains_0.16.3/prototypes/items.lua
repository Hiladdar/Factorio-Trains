require("item.hsmd-cargo-wagon-mk2")
require("item.hsmd-cargo-wagon-mk3")
require("item.hsmd-cargo-wagon-mk4")

require("item.hsmd-fluid-wagon-mk2")
require("item.hsmd-fluid-wagon-mk3")
require("item.hsmd-fluid-wagon-mk4")
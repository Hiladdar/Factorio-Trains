This mod does several things, specifically train breaking performance and cargo wagons size.

1.  Three new cargo wagons, with cargo size of 80, 120, and 160.  The idea here is that existing cargo wagons are stacked on top of each other, i.e. 2 cargo wagons for the one that can haul 80 stacks of stuff and so on.  The drawback is that the stacked cargo wagons are not as structurally sound as base game 40 cargo size cargo wagons.  Also the draw back for having stacked cargo wagons, is that they progressively a bit heavier, and offer greater air resistance.  I designed that as a drawback to the larger capacity.

2.  Three new fluid wagons, with capacity of 50k, 75k, and 100k capacity.  The drawbacks on the stacked fluid wagons are similar to cargo wagon drawbacks.

3.  Breaking force is expanded, by 25 percent per level beyond the base game.

Some technical and mod design notes.

In this mod I wanted to keep acceleration the same, but have max speed adjusted upward as an infinite research, but upon reviewing how research is implemented within the game, that did not appear to be doable.  It looks like there needs to be expansion to a table which tracks infinite research, creation of some variables, sorting out the sort order for that within that table.  That table currently has I believe 26 variables, one for each letter of the English alphabet.  I think upper case letters can be use without dorking up the sort order.  I'll keep that as a possible future release for this mod, a fairly low priority atm.  In the end, I decided to limit the scope of this mod to just train breaking, and cargo wagons.

I do have a lot of other ideas I would like to implement as a mod, but my preference is to chop them up into bite size programming pieces with each mode as a stand along mod, or not requiring more than few other mods.  This application developmental strategy should facilitate less buggy code.  This smaller mod design should facilitate integration of one of my mods into a game which has several large mods.  In the case of this mod, only cargo wagons are introduced

Integration with other mods by other authors: Within my mods, my intent is to not have any dependencies build on what other mod developers, since that could inadvertently break my mod or someone else�s mod.  Along the same line, all the variables within my mod start out with the string "hsmd".  This should resolve any variable naming collation issues.

I can do some graphics work, but I know only enough to be dangerous to myself.  So if you can see the difference in the icons and research, without being too much of a detractor from playing the game.  I also chose to keep graphics at a lower resolution, so that more players with lower end graphics cards would be able to use add this mod.

The companion mod for this would be Hiladdar Fuels mod, which deals with acceleration and max speed for trains and vehicles.   I expect to release that mod within a few releasing this mod, since I was concurrently coding and testing them

Attribution:

The inspiration for larger cargo wagons came from NapusMod_1.3.3
The inspiration for train breaking came from op_train_speed_1.0.8
The tools for programming were notepad.exe, and adpad.exe
Graphics ... pcpaint, pcpaint 3d, gimp, as well as lunapic, a web based graphics editor
